/**
 * VynceAI Extension - Background Service Worker
 * Handles API communication and message routing between popup and content scripts
 */

// Import the API module using importScripts or dynamic import
// Since we can't use top-level import in service workers without "type": "module"
// We'll use dynamic import inside an async context

// Configuration
// Try production backend first, fallback to localhost if needed
const API_BASE_URL = 'https://vynceai.onrender.com';
// const API_BASE_URL = 'http://127.0.0.1:8000'; // Uncomment for local development
const API_ENDPOINTS = {
  chat: '/api/v1/ai/chat',
  query: '/api/v1/ai/query',
  models: '/api/v1/ai/models',
  health: '/api/v1/utils/health'
};

console.log('VynceAI Background Service Worker initializing...');

// Wake up backend and test connection on startup
wakeUpBackend();

async function wakeUpBackend() {
  console.log('🔄 Waking up backend server...');
  
  try {
    // Set a longer timeout for initial wake-up (Render free tier can take 30-60 seconds)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 90000); // 90 second timeout for wake-up
    
    const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.health}`, {
      signal: controller.signal,
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ Backend connected successfully:', data);
      
      // Store backend status in storage
      chrome.storage.local.set({ 
        backendStatus: 'connected',
        lastConnected: Date.now()
      });
    } else {
      console.warn('⚠️ Backend returned error:', response.status);
      chrome.storage.local.set({ 
        backendStatus: 'error',
        lastError: response.status
      });
    }
  } catch (error) {
    if (error.name === 'AbortError') {
      console.warn('⏱️ Backend wake-up timeout (this is normal for first request on Render free tier)');
      console.log('💡 Backend is waking up in the background. Try your request in 30-60 seconds.');
      
      // Continue trying in the background
      retryConnectionInBackground();
    } else {
      console.warn('⚠️ Backend not reachable:', error.message);
    }
    
    chrome.storage.local.set({ 
      backendStatus: 'disconnected',
      lastError: error.message
    });
  }
}

/**
 * Retry connection in background after initial timeout
 * This ensures the backend wakes up even if the first request times out
 */
async function retryConnectionInBackground() {
  console.log('🔄 Retrying connection in background...');
  
  // Wait 10 seconds before retrying
  await new Promise(resolve => setTimeout(resolve, 10000));
  
  for (let i = 0; i < 6; i++) {
    try {
      console.log(`🔄 Retry attempt ${i + 1}/6...`);
      
      const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.health}`, {
        method: 'GET',
        headers: { 'Accept': 'application/json' }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log('✅ Backend woke up successfully!', data);
        
        chrome.storage.local.set({ 
          backendStatus: 'connected',
          lastConnected: Date.now()
        });
        
        return; // Success, stop retrying
      }
    } catch (error) {
      console.log(`⏱️ Retry ${i + 1} failed, waiting 15 seconds...`);
    }
    
    // Wait 15 seconds between retries
    if (i < 5) {
      await new Promise(resolve => setTimeout(resolve, 15000));
    }
  }
  
  console.warn('⚠️ Backend still not responding after 6 retries. Will use mock responses.');
}

async function checkBackendConnection() {
  try {
    const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.health}`, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });
    
    if (response.ok) {
      console.log('✅ Backend connected successfully');
      return true;
    } else {
      console.warn('⚠️ Backend returned error:', response.status);
      return false;
    }
  } catch (error) {
    console.warn('⚠️ Backend not reachable:', error.message);
    return false;
  }
}

/**
 * Call the real FastAPI backend with mode-based routing
 */
async function callBackend(mode, prompt, context = null, memory = null) {
  try {
    console.log('Calling backend API:', { mode, prompt: prompt.substring(0, 50) + '...' });
    
    // Determine model based on mode
    const model = mode === 'site-specific' ? 'gemini-2.5-flash' : 'llama-3.3-70b-versatile';
    
    const payload = {
      model: model,
      prompt: prompt
      // Note: Don't send 'mode' - backend handles routing automatically based on context
    };
    
    // Add context if available (primarily for site-specific mode)
    if (context) {
      payload.context = {
        url: context.url,
        title: context.title,
        selectedText: context.selectedText,
        pageContent: context.textContent
      };
    }
    
    // Add memory if available
    if (memory && memory.length > 0) {
      payload.memory = memory;
    }
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60000); // 60 second timeout
    
    try {
      const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.chat}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      console.log('✅ Backend response received');
      
      return {
        text: data.response || data.message || data.text,
        model: data.model || model,
        tokens: data.tokens || 0,
        success: true,
        source: 'backend'
      };
      
    } catch (fetchError) {
      clearTimeout(timeoutId);
      
      if (fetchError.name === 'AbortError') {
        console.warn('⏱️ Request timeout. Using mock response.');
      } else {
        console.warn('❌ Backend request failed:', fetchError.message);
      }
      
      // Fallback to mock
      return getMockResponse(model, prompt);
    }
    
  } catch (error) {
    console.error('💥 API call failed:', error);
    return getMockResponse(model, prompt);
  }
}

function getMockResponse(model, prompt) {
  console.log('📝 Using mock response for:', model);
  
  return new Promise((resolve) => {
    setTimeout(() => {
      const responses = {
        'gemini-2.5-flash': `🚀 **VynceAI Response** (Gemini 2.5 Flash)\n\nI understand you're asking about "${prompt.substring(0, 50)}..."\n\nHere's my analysis:\n\n✨ **Key Points:**\n• This is an intelligent response\n• Backend API: ${API_BASE_URL}\n• Check if the backend is running and API keys are configured\n\n💡 **Note:** This is a demo response. Ensure your backend is running to get real AI responses!`,
        'gemini-1.5-flash': `Quick response to "${prompt}"!\n\n⚡ **Fast Analysis:**\n- Key insight #1\n- Key insight #2\n- Key insight #3\n\nNeed more details?`,
        'gemini-2.5-pro': `Comprehensive analysis of "${prompt}":\n\n🎯 **Deep Dive:**\n1. Contextual understanding\n2. Multiple perspectives\n3. Detailed recommendations\n\nHow can I help further?`
      };
      
      resolve({
        text: responses[model] || `VynceAI response from ${model}: I received your message "${prompt}". This is a demo response. The server is now connected!`,
        model,
        tokens: Math.floor(Math.random() * 500) + 100,
        success: true,
        mock: true
      });
    }, 1000 + Math.random() * 1000);
  });
}

// Extension installation/update handler
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('VynceAI Extension installed successfully!');
    
    // Set default settings
    chrome.storage.local.set({
      selectedModel: 'gemini-2.5-flash',
      conversationHistory: [],
      settings: {
        autoContext: true,
        darkMode: true,
        apiKey: null
      }
    });
    
    // Open welcome page (optional)
    // chrome.tabs.create({ url: 'https://vynceai.com/welcome' });
  } else if (details.reason === 'update') {
    console.log('VynceAI Extension updated to version:', chrome.runtime.getManifest().version);
  }
});

// Listen for messages from popup and content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request.type);
  
  switch (request.type) {
    case 'SEND_PROMPT':
      handleSendPrompt(request.payload, sendResponse);
      return true; // Keep channel open for async response
      
    case 'EXECUTE_COMMAND':
      handleExecuteCommand(request.payload, sendResponse);
      return true;
      
    case 'GET_TAB_INFO':
      handleGetTabInfo(sender, sendResponse);
      return true;
      
    case 'EXECUTE_ACTION':
      handleExecuteAction(request.payload, sendResponse);
      return true;
      
    case 'SAVE_SETTINGS':
      handleSaveSettings(request.payload, sendResponse);
      return true;
      
    case 'GET_AVAILABLE_MODELS':
      handleGetAvailableModels(sendResponse);
      return true;
      
    case 'OPEN_SITE':
      handleOpenSite(request.url, sendResponse);
      return true;
      
    case 'AUTOMATION_EXECUTE':
      handleAutomationExecute(request.command, sendResponse);
      return true;
      
    case 'PARSE_AUTOMATION_COMMAND':
      handleParseAutomationCommand(request.command, sendResponse);
      return true;
      
    default:
      console.warn('Unknown message type:', request.type);
      sendResponse({ success: false, error: 'Unknown message type' });
  }
});

/**
 * Handle sending prompt to AI backend with mode-based routing
 */
async function handleSendPrompt(payload, sendResponse) {
  const { mode, prompt, context, memory } = payload;
  
  try {
    const selectedMode = mode || 'site-specific'; // Default to site-specific
    console.log(`Sending prompt in ${selectedMode} mode:`, prompt);
    
    // Call backend API with mode-based routing
    const response = await callBackend(selectedMode, prompt, context, memory);
    
    console.log('AI Response received:', response);
    
    sendResponse({
      success: true,
      data: {
        response: response.text,
        model: response.model,
        tokens: response.tokens,
        timestamp: Date.now()
      }
    });
    
  } catch (error) {
    console.error('Error in handleSendPrompt:', error);
    
    sendResponse({
      success: false,
      error: error.message || 'Failed to get AI response'
    });
  }
}

/**
 * Get available models from backend
 */
async function handleGetAvailableModels(sendResponse) {
  try {
    console.log('Fetching available models from backend...');
    
    const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.models}`);
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    const data = await response.json();
    console.log('✅ Available models fetched:', data);
    
    sendResponse({
      success: true,
      models: data.models || []
    });
    
  } catch (error) {
    console.error('❌ Error fetching models:', error);
    
    // Return fallback models based on what's typically configured
    sendResponse({
      success: false,
      error: error.message,
      models: [
        // Gemini models (VynceAI uses Gemini only)
        { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', provider: 'gemini' },
        { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro', provider: 'gemini' },
        { id: 'gemini-flash-latest', name: 'Gemini Flash Latest', provider: 'gemini' }
      ]
    });
  }
}

/**
 * Get information about the current tab
 */
async function handleGetTabInfo(sender, sendResponse) {
  try {
    const tab = sender.tab;
    
    if (!tab) {
      throw new Error('No active tab found');
    }
    
    sendResponse({
      success: true,
      data: {
        url: tab.url,
        title: tab.title,
        favIconUrl: tab.favIconUrl,
        id: tab.id
      }
    });
    
  } catch (error) {
    console.error('Error getting tab info:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * Execute an action on a webpage (via content script)
 */
async function handleExecuteAction(payload, sendResponse) {
  const { action, params, tabId } = payload;
  
  try {
    // Get active tab if tabId not provided
    let targetTabId = tabId;
    
    if (!targetTabId) {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      targetTabId = activeTab.id;
    }
    
    // Send action to content script
    const response = await chrome.tabs.sendMessage(targetTabId, {
      type: 'EXECUTE_ACTION',
      action,
      params
    });
    
    sendResponse({
      success: true,
      data: response
    });
    
  } catch (error) {
    console.error('Error executing action:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * Save user settings to storage
 */
async function handleSaveSettings(payload, sendResponse) {
  try {
    await chrome.storage.local.set({ settings: payload });
    
    sendResponse({
      success: true,
      message: 'Settings saved successfully'
    });
    
  } catch (error) {
    console.error('Error saving settings:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * Handle opening a new site in a new tab
 */
async function handleOpenSite(url, sendResponse) {
  try {
    console.log('🌐 Opening new tab:', url);
    
    // Validate URL format
    if (!url || typeof url !== 'string') {
      throw new Error('Invalid URL provided');
    }
    
    // Ensure URL has protocol
    let validUrl = url;
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      validUrl = 'https://' + validUrl;
    }
    
    // Create new tab
    const newTab = await chrome.tabs.create({ url: validUrl });
    
    sendResponse({
      success: true,
      message: `Opened ${validUrl} in new tab`,
      data: {
        tabId: newTab.id,
        url: validUrl
      }
    });
    
  } catch (error) {
    console.error('Error opening site:', error);
    sendResponse({
      success: false,
      error: error.message || 'Failed to open site'
    });
  }
}

// ============================================
// COMMAND EXECUTION (Phase 7)
// ============================================

/**
 * Execute browser automation commands
 */
async function handleExecuteCommand(payload, sendResponse) {
  const { command } = payload;
  const lowerCommand = command.toLowerCase();
  
  try {
    // Get active tab
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!activeTab) {
      throw new Error('No active tab found');
    }
    
    // Parse and execute commands
    if (lowerCommand.includes('scroll down') || lowerCommand === 'scroll') {
      await executeScroll(activeTab.id, 'down');
      sendResponse({ success: true, message: 'Scrolled down' });
      
    } else if (lowerCommand.includes('scroll up')) {
      await executeScroll(activeTab.id, 'up');
      sendResponse({ success: true, message: 'Scrolled up' });
      
    } else if (lowerCommand.includes('open new tab') || lowerCommand.includes('new tab')) {
      const url = extractUrl(lowerCommand) || 'https://www.google.com';
      await chrome.tabs.create({ url });
      sendResponse({ success: true, message: `Opened new tab: ${url}` });
      
    } else if (lowerCommand.includes('close tab') || lowerCommand.includes('close this')) {
      await chrome.tabs.remove(activeTab.id);
      sendResponse({ success: true, message: 'Tab closed' });
      
    } else if (lowerCommand.includes('go to ') || lowerCommand.includes('open ') || lowerCommand.includes('navigate to ')) {
      const url = extractUrl(lowerCommand);
      if (url) {
        await chrome.tabs.update(activeTab.id, { url });
        sendResponse({ success: true, message: `Navigating to ${url}` });
      } else {
        throw new Error('Could not extract URL from command');
      }
      
    } else if (lowerCommand.includes('contact') || lowerCommand.includes('email') || lowerCommand.includes('phone')) {
      const contacts = await extractContacts(activeTab.id);
      sendResponse({ 
        success: true, 
        message: `Found contacts:\n${contacts.emails.join(', ')}\n${contacts.phones.join(', ')}`,
        data: contacts
      });
      
    } else if (lowerCommand.includes('back')) {
      await chrome.tabs.goBack(activeTab.id);
      sendResponse({ success: true, message: 'Navigated back' });
      
    } else if (lowerCommand.includes('forward')) {
      await chrome.tabs.goForward(activeTab.id);
      sendResponse({ success: true, message: 'Navigated forward' });
      
    } else if (lowerCommand.includes('refresh') || lowerCommand.includes('reload')) {
      await chrome.tabs.reload(activeTab.id);
      sendResponse({ success: true, message: 'Page refreshed' });
      
    } else {
      throw new Error('Command not recognized. Try: scroll, open tab, close tab, go to [url], fetch contacts');
    }
    
  } catch (error) {
    console.error('Command execution error:', error);
    sendResponse({
      success: false,
      error: error.message || 'Failed to execute command'
    });
  }
}

/**
 * Execute scroll command on page
 */
async function executeScroll(tabId, direction) {
  const scrollAmount = direction === 'down' ? 400 : -400;
  
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (amount) => {
      window.scrollBy({ top: amount, behavior: 'smooth' });
    },
    args: [scrollAmount]
  });
}

/**
 * Extract URL from command text
 */
function extractUrl(command) {
  // Check for explicit URL
  const urlMatch = command.match(/(?:https?:\/\/)?(?:www\.)?([a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?)/);
  if (urlMatch) {
    let url = urlMatch[0];
    if (!url.startsWith('http')) {
      url = 'https://' + url;
    }
    return url;
  }
  
  // Extract site name and construct URL
  const siteMatch = command.match(/(?:go to|open|navigate to)\s+([a-zA-Z0-9]+)/i);
  if (siteMatch) {
    const site = siteMatch[1];
    return `https://www.${site}.com`;
  }
  
  return null;
}

/**
 * Extract contact information from page
 */
async function extractContacts(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const text = document.body.innerText;
      
      // Extract emails
      const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
      const emails = [...new Set(text.match(emailRegex) || [])];
      
      // Extract phone numbers
      const phoneRegex = /(?:\+\d{1,3}[-.\s]?)?(?:\(?\d{1,4}\)?[-.\s]?)?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}/g;
      const phones = [...new Set(text.match(phoneRegex) || [])]
        .filter(p => p.replace(/\D/g, '').length >= 10)
        .slice(0, 5);
      
      return { emails, phones };
    }
  });
  
  return results[0]?.result || { emails: [], phones: [] };
}

// ============================================
// AUTOMATION COMMAND HANDLING
// ============================================

/**
 * Handle automation execute request
 */
async function handleAutomationExecute(command, sendResponse) {
  try {
    const result = await executeAutomationCommand(command);
    sendResponse(result);
  } catch (error) {
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * Handle automation command parsing request
 */
async function handleParseAutomationCommand(command, sendResponse) {
  try {
    const result = await parseAutomationCommand(command);
    sendResponse({
      success: true,
      parsedCommand: result
    });
  } catch (error) {
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

/**
 * Parse automation command using AI
 */
async function parseAutomationCommand(command) {
  try {
    const prompt = `Parse this automation command into a JSON structure with 'action' and 'params' fields.

Supported actions:
- youtube_search: params should have 'query'
- google_form_fill: params should have 'formData' object with key-value pairs
- submit_form: no params needed
- click: params should have 'selector' (element to click)
- fill: params should have 'selector' and 'value'

Command: "${command}"

Respond ONLY with valid JSON, no explanation.`;

    const response = await callBackend('general', prompt);
    
    if (response.success && response.text) {
      try {
        // Try to extract JSON from response
        const jsonMatch = response.text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          return parsed;
        }
      } catch (e) {
        console.error('Failed to parse AI response as JSON:', e);
      }
    }

    return null;

  } catch (error) {
    console.error('AI command parsing error:', error);
    return null;
  }
}

/**
 * Execute automation command on active tab
 */
async function executeAutomationCommand(command) {
  try {
    console.log('[Background] Executing automation command:', command);

    // Get active tab
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!activeTab) {
      throw new Error('No active tab found');
    }

    // Step 1: Inject command parser
    try {
      await chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        files: ['content/command-parser.js']
      });
      console.log('[Background] Command parser injected');
    } catch (injectError) {
      console.log('[Background] Command parser already injected:', injectError.message);
    }

    // Step 2: Inject automation engine
    try {
      await chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        files: ['content/automation-engine.js']
      });
      console.log('[Background] Automation engine injected');
    } catch (injectError) {
      console.log('[Background] Automation engine already injected:', injectError.message);
    }

    // Wait a bit for scripts to initialize
    await new Promise(resolve => setTimeout(resolve, 400));

    // Step 3: Parse the command (convert natural language to structured command)
    const parseResult = await chrome.tabs.sendMessage(activeTab.id, {
      type: 'PARSE_COMMAND',
      command: command
    });

    if (!parseResult || !parseResult.success) {
      throw new Error('Failed to parse command: ' + (parseResult?.error || 'Unknown error'));
    }

    console.log('[Background] Parsed command:', parseResult.parsedCommand);

    // Step 4: Execute the parsed command
    const response = await chrome.tabs.sendMessage(activeTab.id, {
      type: 'AUTOMATION_COMMAND',
      command: parseResult.parsedCommand
    });

    console.log('[Background] Automation response:', response);

    if (response && response.success) {
      return {
        success: true,
        message: response.data?.message || 'Automation completed successfully'
      };
    } else {
      throw new Error(response?.error || 'Automation failed');
    }

  } catch (error) {
    console.error('[Background] Automation command execution failed:', error);
    throw error;
  }
}

console.log('✅ VynceAI Background Service Worker loaded successfully (with automation support)');

// ============================================
// KEYBOARD SHORTCUT HANDLER
// ============================================

/**
 * Handle keyboard shortcuts (Alt+A)
 */
chrome.commands.onCommand.addListener((command) => {
  console.log('🎹 Keyboard shortcut triggered:', command);
  
  if (command === "activate-vynce") {
    // Open the VynceAI popup
    chrome.action.openPopup()
      .then(() => {
        console.log('✅ VynceAI popup opened via keyboard shortcut');
      })
      .catch((error) => {
        // If popup fails to open (e.g., on chrome:// pages), show notification
        console.warn('⚠️ Could not open popup:', error.message);
        
        // Alternative: Create a new tab with the extension URL
        chrome.tabs.create({ 
          url: chrome.runtime.getURL("popup/popup.html"),
          active: true
        }).then(() => {
          console.log('✅ VynceAI opened in new tab');
        });
      });
  }
});

console.log('✅ Keyboard shortcut listener registered (Alt+A)');

